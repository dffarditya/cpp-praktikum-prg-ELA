#include <iostream>
using namespace std;
int main(){
    string a="Praktikum Pemrograman";
    string *s=&a;
    cout<<*s;
}