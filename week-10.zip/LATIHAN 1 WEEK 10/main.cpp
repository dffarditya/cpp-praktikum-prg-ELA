#include <iostream>
#include <stdio.h>
using namespace std;

void swap(int *a, int *b)
{
    int temp=*a;
    *a=*b;
    *b=temp;
}

int main() {
	int a,b;
	cout<<"Masukkan nilai pertama: ";
	cin>>a;
	cout<<"Masukkan nilai kedua: ";
	cin>>b;

	cout<<"Angka sebelum swap: "<<"a= "<<a<<", b= "<<b<<endl;

	swap(&a, &b);
	cout<<"Angka setelah swap: "<<"a= "<<a<<", b= "<<b;
	

}