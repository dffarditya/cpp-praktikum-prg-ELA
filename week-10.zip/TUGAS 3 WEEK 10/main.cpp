#include <iostream>
#include <stdio.h>
using namespace std;

void swap(int *a, int *b)
{
    int temp=*a;
    *a=*b;
    *b=temp;
}

int main() {
	int a=1,b=2;
	cout<<"Angka sebelum swap: "<<"a= "<<a<<", b= "<<b<<endl;

	swap(&a, &b);
	cout<<"Angka setelah swap: "<<"a= "<<a<<", b= "<<b;
	

}