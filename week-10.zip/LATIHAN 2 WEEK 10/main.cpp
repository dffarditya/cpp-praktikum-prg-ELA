#include <iostream>
#include <stdio.h>
using namespace std;

int x, y, jumlah, kurang, kali;
double bagi;
int* a=&x;
int* b=&y;
int* ku=&kurang;
int* ju=&jumlah;
int* ka=&kali;
double* ba=&bagi;
void calculate();
void input()
{
    cout<<"Masukkan angka pertama: ";
    cin>>x;
    s:
    cout<<"Masukkan angka kedua: ";
    cin>>y;
    if(y==0)
    {
        cout<<"Angka tidak valid!";
        goto s;
    }
    else
    {
        calculate();
    }
}

void calculate()
{
    jumlah=*a+*b;
    kurang=*a-*b;
    kali=*a * *b;
    bagi=*a/ *b;
}

void display()
{
    printf("Hasil penjumlahan: %d\n", *ju);
    printf("Hasil pengurangan: %d\n", *ku);
    printf("Hasil perkalian: %d\n", *ka);
    cout<<"Hasil pembagian: "<<*ba;
}

int main(){
    input();
    display();
    
}