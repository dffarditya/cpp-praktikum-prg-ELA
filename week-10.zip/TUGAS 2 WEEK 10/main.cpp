#include <iostream>
using namespace std;
int main(){
    char kata[]="Gadjah Mada";
    char *empat=&kata[3];
    cout<<"Kalimatnya adalah "<<kata<<endl;
    cout<<"Huruf keempat adalah "<<*empat;
}