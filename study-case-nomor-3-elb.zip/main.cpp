    #include <iostream>
    #include <stdio.h>
    using namespace std;
    struct dataMahasiswa
    {
        string nama, status;
        string NIM;
        float nilaiTugas;
        float nilaiUAS;
        float nilaiUTS;
        float nilaiRataRata;
    };
    
    dataMahasiswa mahasiswa[100000];
    int N, s=0;
    
    
    void tambahMahasiswa()
    {
        cout<<"Masukkan jumlah mahasiswa yang akan ditambahkan: ";
        cin>>N;
        cout<<"-------------------------------------------------"<<endl;
        for(int i=s; i<N+s; i++)
        {
            cout<<"Data Mahasiswa ke-"<<i+1<<endl;
            cout<<"Nama: ";
            cin.ignore();
            getline(cin, mahasiswa[i].nama);
            cout<<"NIM: ";
            cin>>mahasiswa[i].NIM;
            cout<<"Nilai Tugas: ";
            cin>>mahasiswa[i].nilaiTugas;
            cout<<"Nilai UTS: ";
            cin>>mahasiswa[i].nilaiUTS;
            cout<<"Nilai UAS: ";
            cin>>mahasiswa[i].nilaiUAS;
            cout<<endl;
            
            mahasiswa[i].nilaiRataRata=(mahasiswa[i].nilaiTugas + mahasiswa[i].nilaiUTS + mahasiswa[i].nilaiUAS)/3;
            
            if(mahasiswa[i].nilaiRataRata>75)
            {
                mahasiswa[i].status="Lulus";
            }
            else
            {
                mahasiswa[i].status="Tidak Lulus";
            }
        }
        s+=N;
        
    }
    
    void tampilkanMahasiswa()
    {
        if(s==0)
        {
            cout<<endl;
            cout<<"Belum ada data mahasiswa!"<<endl;
            cout<<endl;
            return;
        }
        cout<<endl;
        for(int i=0; i<s; i++)
        {
            cout<<"Data Mahasiswa ke-"<<i+1<<endl;
            cout<<"Nama: "<<mahasiswa[i].nama<<endl;
            cout<<"NIM: "<<mahasiswa[i].NIM<<endl;
            cout<<"Nilai Rata-Rata: "<<mahasiswa[i].nilaiRataRata<<endl;
            cout<<"Status: "<<mahasiswa[i].status<<endl;
            cout<<endl;
        }
    }
    
    void tampilkanMahasiswaLulus()
    {
         if(s==0)
        {
            cout<<endl;
            cout<<"Belum ada data mahasiswa!"<<endl;
            cout<<endl;
            return;
        }
        cout<<endl;
        for(int i=0; i<s; i++)
        {
            if (mahasiswa[i].nilaiRataRata>75)
            {
                cout<<"Data Mahasiswa ke-"<<i+1<<endl;
                cout<<"Nama: "<<mahasiswa[i].nama<<endl;
                cout<<"NIM: "<<mahasiswa[i].NIM<<endl;
                cout<<"Nilai Rata-Rata: "<<mahasiswa[i].nilaiRataRata<<endl;
                cout<<"Status: "<<mahasiswa[i].status<<endl;
                cout<<endl;
            }
        }
    }
    int main (){
        int pilihan;
        do
        {
            cout<<"---------------------------------"<<endl;
            cout<<"Sistem Pengelolaan Data Mahasiswa"<<endl;
            cout<<"---------------------------------"<<endl;
            cout<<"1. Tambah data mahasiswa"<<endl;
            cout<<"2. Tampilkan semua data mahasiswa"<<endl;
            cout<<"3. Tampilkan data mahasiswa dengan rata-rata >75"<<endl;
            cout<<"4. Keluar"<<endl;
            cout<<"Pilih Opsi: ";
            cin>>pilihan;
            
            switch(pilihan)
            {
                case 1:
                tambahMahasiswa();
                break;
                case 2:
                tampilkanMahasiswa();
                break;
                case 3:
                tampilkanMahasiswaLulus();
                break;
                case 4:
                cout<<"Terima kasih!"<<endl;
                break;
                default:
                cout<<endl<<"Error!!"<<endl;
            }
        }
        while(pilihan!=4);
    }