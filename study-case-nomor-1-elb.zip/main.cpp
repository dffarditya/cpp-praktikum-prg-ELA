#include <iostream>
using namespace std;
int main(){
    int pilihan, jumlah, total, diskon, totalAkhir;
    char lanjut;
    
    lanjut='y';
    while(lanjut=='y')
    {
        cout<<"Selamat datang di sistem penjualan tiket konser!"<<endl;
        cout<<"1. Tiket VIP (Rp 1.000.000)"<<endl;
        cout<<"2. Tiket Reguler (Rp 500.000)"<<endl;
        cout<<"3. Tiket Ekonomi (Rp 200.000)"<<endl;
        cout<<"Masukkan pilihan anda (1-3): ";
        cin>>pilihan;
        cout<<"Masukkan jumlah tiket yang ingin dibeli: ";
        cin>>jumlah;
        cout<<endl;
        switch(pilihan)
        {
            case 1:
            total=1000000*jumlah;
            break;
            case 2:
            total=500000*jumlah;
            break;
            case 3:
            total=200000*jumlah;
            break;
            default:
            cout<<"Pilihan Tidak ada!"<<endl;
            break;
        }
        cout<<"Total harga sebelum diskon: Rp"<<total<<endl;
        
        if(total>200000)
        {
            diskon=0.1*total;
        }
        else
        {
            diskon=0;
        }
        totalAkhir=total-diskon;
        cout<<"Diskon: Rp"<<diskon<<endl;
        cout<<"Total harga setelah diskon: Rp"<<totalAkhir<<endl;
        cout<<endl<<"Apakah anda ingin membeli tiket lagi? (y/n): ";
        cin>>lanjut;
    }
    cout<<"Terima kasih!";
    
}